<?php
interface EndpointRepository {}
