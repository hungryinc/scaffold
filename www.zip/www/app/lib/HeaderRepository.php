<?php
interface HeaderRepository {}
