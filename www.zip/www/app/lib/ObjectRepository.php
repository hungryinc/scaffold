<?php
interface ObjectRepository {}
